# Task1 GLMM analysis without R Markdown rendering
suppressPackageStartupMessages({suppressPackageStartupMessages({
  # Use base recommended packages; avoid installing at runtime
  library(MASS)
  library(nlme)
  have_haven <- requireNamespace('haven', quietly = TRUE)
  if (!have_haven) {
    # Fallback for Stata files
    library(foreign)
  }
})})

# Paths
village_path <- 'data/AEJApp-2009-0289-data/village.dta'
household_path <- 'data/AEJApp-2009-0289-data/household.dta'

# Load data
if (requireNamespace('haven', quietly = TRUE)) {
  vil <- haven::read_dta(village_path)
  hh  <- haven::read_dta(household_path)
} else {
  vil <- foreign::read.dta(village_path)
  hh  <- foreign::read.dta(household_path)
}

# Construct district index from dist1..dist25 dummy columns (if present)
dist_cols <- grep('^dist[0-9]+$', names(hh), value = TRUE)
if (length(dist_cols) > 0) {
  ord <- order(as.numeric(sub('^dist', '', dist_cols)))
  dist_cols <- dist_cols[ord]
  district <- rep(0, nrow(hh))
  for (i in seq_along(dist_cols)) {
    v <- as.numeric(hh[[dist_cols[i]]])
    v[is.na(v)] <- 0
    district <- district + i * v
  }
  hh$district <- district
}

# Crop control summary
cc_vars <- c('paddy','wheat','cereal','pulse','bulb','seed','cash')
cc_present <- cc_vars[cc_vars %in% names(hh)]
if (length(cc_present) == length(cc_vars)) {
  hh$cropcontrol <- rowMeans(hh[cc_vars], na.rm = TRUE)
}

# Restrict to complete cases
hh <- hh[complete.cases(hh), ]

# Outlier removal using IQR on log(totinc)
log_totinc <- log(hh$totinc)
out <- boxplot.stats(log_totinc)$out
hhfilt <- hh[!(log_totinc %in% out), ]

# Ensure grouping and factors
hhfilt$bihar    <- as.factor(hhfilt$bihar)
if ('district' %in% names(hhfilt)) hhfilt$district <- as.factor(hhfilt$district)
hhfilt$village  <- as.factor(hhfilt$village)
if ('caste' %in% names(hhfilt)) hhfilt$caste <- as.factor(as.character(hhfilt$caste))

# Fit GLMMs
# Base model: 3-level random effects bihar/district/village
base_model <- try(suppressWarnings(glmmPQL(totinc ~ domlow,
                             random = ~ 1 | bihar/district/village,
                             family = gaussian(link = 'log'),
                             data = hhfilt,
                             verbose = FALSE)), silent = TRUE)

# Full controls model
full_formula <- as.formula(paste(
  'totinc ~',
  paste(c('literate','totland','caste','cropcontrol',
          'bus3','tele3','ps3','pds3','bank3','pps3','ms3','ss3','phc3','hosp3',
          'gwdevelopment','rainfall','gwavailability','river','canal','noalkal','nolog','nosoil','noflood',
          'area','pmixdominant','tolaparea','domlow'), collapse = ' + ')
))
full_model <- try(suppressWarnings(glmmPQL(full_formula,
                             random = ~ 1 | bihar/district/village,
                             family = gaussian(link = 'log'),
                             data = hhfilt,
                             verbose = FALSE)), silent = TRUE)

extract_domlow <- function(mod) {
  if (inherits(mod, 'try-error')) return(NULL)
  s <- summary(mod)
  if (!is.null(s$tTable)) {
    tt <- as.data.frame(s$tTable)
    rn <- rownames(tt)
    # Match exact 'domlow' term
    if ('domlow' %in% rn) {
      row <- tt['domlow', , drop = FALSE]
      return(list(
        estimate = unname(row$Value),
        se = unname(row$`Std.Error`),
        df = unname(row$DF),
        t = unname(row$`t-value`),
        p = unname(row$`p-value`)
      ))
    }
  }
  return(NULL)
}

res_base <- extract_domlow(base_model)
res_full <- extract_domlow(full_model)

# Prepare output
out_list <- list(
  sample_size = nrow(hhfilt),
  task = 'Task1',
  models = list(
    base = res_base,
    full_controls = res_full
  )
)

# Write artifacts
art_dir <- file.path('artifacts')
if (!dir.exists(art_dir)) dir.create(art_dir, recursive = TRUE, showWarnings = FALSE)
out_file <- file.path(art_dir, 'results_task1.json')
json_txt <- paste0(
  '{',
  '"task":"', out_list$task, '",',
  '"sample_size":', out_list$sample_size, ',',
  '"base":', if (is.null(res_base)) 'null' else paste0('{',
      '"estimate":', signif(res_base$estimate, 6), ',',
      '"se":', signif(res_base$se, 6), ',',
      '"df":', round(res_base$df, 0), ',',
      '"t":', signif(res_base$t, 6), ',',
      '"p":', signif(res_base$p, 6),
    '}'), ',',
  '"full_controls":', if (is.null(res_full)) 'null' else paste0('{',
      '"estimate":', signif(res_full$estimate, 6), ',',
      '"se":', signif(res_full$se, 6), ',',
      '"df":', round(res_full$df, 0), ',',
      '"t":', signif(res_full$t, 6), ',',
      '"p":', signif(res_full$p, 6),
    '}'),
  '}'
)
writeLines(json_txt, out_file)

cat('Task1 completed. Results written to', out_file, '\n')
if (!is.null(res_base)) cat('Base model domlow: t =', signif(res_base$t, 4), 'p =', signif(res_base$p, 4), '\n') else cat('Base model failed or domlow not found.\n')
if (!is.null(res_full)) cat('Full controls domlow: t =', signif(res_full$t, 4), 'p =', signif(res_full$p, 4), '\n') else cat('Full controls model failed or domlow not found.\n')
