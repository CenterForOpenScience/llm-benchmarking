# Task2 GLMM analysis without R Markdown rendering
suppressPackageStartupMessages({suppressPackageStartupMessages({
  library(MASS)
  library(nlme)
  have_haven <- requireNamespace('haven', quietly = TRUE)
  if (!have_haven) {
    library(foreign)
  }
})})

# Paths
household_path <- 'data/AEJApp-2009-0289-data/household.dta'

# Load data
if (requireNamespace('haven', quietly = TRUE)) {
  hh <- haven::read_dta(household_path)
} else {
  hh <- foreign::read.dta(household_path)
}

# Restrict to complete cases
hh <- hh[complete.cases(hh), ]

# Outlier removal using IQR on log(totinc)
log_totinc <- log(hh$totinc)
out <- boxplot.stats(log_totinc)$out
hhfilt <- hh[!(log_totinc %in% out), ]

# Ensure grouping and factors
hhfilt$bihar    <- as.factor(hhfilt$bihar)
hhfilt$village  <- as.factor(hhfilt$village)
if ('caste' %in% names(hhfilt)) hhfilt$caste <- as.factor(as.character(hhfilt$caste))

# Base model with allowed random effects
base_model <- try(suppressWarnings(glmmPQL(totinc ~ domlow,
                             random = ~ 1 | bihar/village,
                             family = gaussian(link = 'log'),
                             data = hhfilt,
                             verbose = FALSE)), silent = TRUE)

# Allowed controls only (literate, totland, caste) with interactions
ctrl_formula <- as.formula('totinc ~ literate * totland * caste * domlow')
ctrl_model <- try(suppressWarnings(glmmPQL(ctrl_formula,
                             random = ~ 1 | bihar/village,
                             family = gaussian(link = 'log'),
                             data = hhfilt,
                             verbose = FALSE)), silent = TRUE)

extract_domlow <- function(mod) {
  if (inherits(mod, 'try-error')) return(NULL)
  s <- summary(mod)
  if (!is.null(s$tTable)) {
    tt <- as.data.frame(s$tTable)
    rn <- rownames(tt)
    # Exact main-effect term name
    if ('domlow' %in% rn) {
      row <- tt['domlow', , drop = FALSE]
      return(list(
        estimate = unname(row$Value),
        se = unname(row$`Std.Error`),
        df = unname(row$DF),
        t = unname(row$`t-value`),
        p = unname(row$`p-value`)
      ))
    }
  }
  return(NULL)
}

res_base <- extract_domlow(base_model)
res_ctrl <- extract_domlow(ctrl_model)

# Prepare output
out_list <- list(
  sample_size = nrow(hhfilt),
  task = 'Task2',
  models = list(
    base = res_base,
    allowed_controls = res_ctrl
  )
)

# Write artifacts
art_dir <- file.path('artifacts')
if (!dir.exists(art_dir)) dir.create(art_dir, recursive = TRUE, showWarnings = FALSE)
out_file <- file.path(art_dir, 'results_task2.json')
json_txt <- paste0(
  '{',
  '"task":"', out_list$task, '",',
  '"sample_size":', out_list$sample_size, ',',
  '"base":', if (is.null(res_base)) 'null' else paste0('{',
      '"estimate":', signif(res_base$estimate, 6), ',',
      '"se":', signif(res_base$se, 6), ',',
      '"df":', round(res_base$df, 0), ',',
      '"t":', signif(res_base$t, 6), ',',
      '"p":', signif(res_base$p, 6),
    '}'), ',',
  '"allowed_controls":', if (is.null(res_ctrl)) 'null' else paste0('{',
      '"estimate":', signif(res_ctrl$estimate, 6), ',',
      '"se":', signif(res_ctrl$se, 6), ',',
      '"df":', round(res_ctrl$df, 0), ',',
      '"t":', signif(res_ctrl$t, 6), ',',
      '"p":', signif(res_ctrl$p, 6),
    '}'),
  '}'
)
writeLines(json_txt, out_file)

cat('Task2 completed. Results written to', out_file, '\n')
if (!is.null(res_base)) cat('Base model domlow: t =', signif(res_base$t, 4), 'p =', signif(res_base$p, 4), '\n') else cat('Base model failed or domlow not found.\n')
if (!is.null(res_ctrl)) cat('Allowed-controls model domlow: t =', signif(res_ctrl$t, 4), 'p =', signif(res_ctrl$p, 4), '\n') else cat('Allowed-controls model failed or domlow not found.\n')
