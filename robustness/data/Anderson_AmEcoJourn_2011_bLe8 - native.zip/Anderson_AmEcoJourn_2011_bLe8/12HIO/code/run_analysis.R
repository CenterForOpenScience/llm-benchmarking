# Run t-tests on household income by caste grouping and save results (base R version; grouping from 'caste' labels)

# Paths
in_path <- "/app/data/AEJApp-2009-0289-data/household.dta"
out_dir <- "/app/artifacts"
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# Load data using base R's 'foreign' (bundled with R)
df <- foreign::read.dta(in_path, convert.factors = TRUE)

# Ensure variables exist
if (!all(c("totinc", "caste") %in% names(df))) {
  stop("Required variables 'totinc' and 'caste' not found in dataset.")
}

# Normalize caste labels
caste_chr <- trimws(as.character(df$caste))
caste_norm <- tolower(gsub("[^a-z]", "", caste_chr))

# Define lower as ST/SC variants, upper as all others (Back agr + Back oth)
lower_flag <- !is.na(caste_norm) & caste_norm %in% c("stsc", "scst")

group <- ifelse(lower_flag, "lower", ifelse(!is.na(caste_norm), "non_lower", NA))

# Analysis data
an_df <- data.frame(totinc = as.numeric(df$totinc), group = factor(group))
sel <- !is.na(an_df$totinc) & !is.na(an_df$group)
an_df <- an_df[sel, ]

# Ensure both groups present
if (length(unique(an_df$group)) < 2) {
  stop(sprintf("Grouping factor has %d level(s). Counts: lower=%d, non_lower=%d.",
               length(unique(an_df$group)), sum(an_df$group=="lower"), sum(an_df$group=="non_lower")))
}

# Welch two-sample t-test
tt <- t.test(totinc ~ group, data = an_df, var.equal = FALSE)

# Group means and ns
mean_lower <- mean(an_df$totinc[an_df$group == "lower"])
mean_upper <- mean(an_df$totinc[an_df$group == "non_lower"])
 n_lower <- sum(an_df$group == "lower")
 n_upper <- sum(an_df$group == "non_lower")

# Difference (lower - non_lower)
diff_lu <- as.numeric(mean_lower - mean_upper)

# Prepare JSON manually (avoid external packages)
num_fmt <- function(x) {
  if (length(x) == 0 || is.na(x)) return("null")
  # Ensure standard JSON numeric formatting
  as.character(signif(x, 10))
}

make_task_json <- function(task_id) {
  paste0(
    "{",
    "\"task_id\":\"", task_id, "\",",
    "\"metric\":\"t_test_income_by_caste\",",
    "\"group_means\":{\"lower\":", num_fmt(mean_lower), ",\"non_lower\":", num_fmt(mean_upper), "},",
    "\"group_ns\":{\"lower\":", n_lower, ",\"non_lower\":", n_upper, "},",
    "\"mean_difference_lower_minus_non_lower\":", num_fmt(diff_lu), ",",
    "\"t_statistic\":", num_fmt(unname(tt$statistic)), ",",
    "\"df\":", num_fmt(unname(tt$parameter)), ",",
    "\"p_value\":", num_fmt(unname(tt$p.value)),
    "}"
  )
}

execution_json <- paste0(
  "{\"tasks\":[",
  make_task_json("Task1"), ",",
  make_task_json("Task2"),
  "]}"
)

cat(execution_json, file = file.path(out_dir, "execution_result.json"))
cat(make_task_json("Task1"), file = file.path(out_dir, "task1_result.json"))
cat(make_task_json("Task2"), file = file.path(out_dir, "task2_result.json"))

cat("Analysis complete. Results written to /app/artifacts.\n")
