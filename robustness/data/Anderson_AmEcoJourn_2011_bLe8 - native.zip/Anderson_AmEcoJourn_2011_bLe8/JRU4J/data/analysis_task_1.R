# Load minimal dependencies available in base image
suppressPackageStartupMessages({
  library(dplyr)
  library(foreign)
  library(nlme)
})

# Read data (original files under ./data/AEJApp-2009-0289-data/)
household <- read.dta("./data/AEJApp-2009-0289-data/household.dta")
village   <- read.dta("./data/AEJApp-2009-0289-data/village.dta")

# Prepare merge keys and join to attach domhigh to households
village$village <- as.character(village$village)
village$domhigh <- as.character(village$domhigh)

village_domhigh <- village[, c("village", "domhigh")]

household$village <- as.character(household$village)
household$caste   <- as.character(household$caste)

dat <- household %>% dplyr::select(hhcode, village, caste, totinc)

# Left join and filter to valid dominance values (0/1)
dat <- dplyr::left_join(dat, village_domhigh, by = "village") %>%
  dplyr::filter(domhigh %in% c("0", "1"))

# Convert grouping variables to factors explicitly
dat$village <- as.factor(dat$village)
dat$domhigh <- factor(dat$domhigh, levels = c("0", "1"))
dat$caste   <- as.factor(dat$caste)

# Linear mixed-effects model (random intercept for village)
lmm_mod <- nlme::lme(fixed = totinc ~ caste * domhigh,
                     random = ~ 1 | village,
                     data = dat,
                     na.action = na.omit,
                     method = "REML")

# Write outputs to mounted artifacts folder for retrieval
out_file <- "/app/artifacts/results_task1.txt"
con <- file(out_file, open = "wt")
sink(con)
sink(con, type = "message")
cat("Linear mixed-effects model (nlme): totinc ~ caste * domhigh + (1|village)\n\n")
print(summary(lmm_mod))
cat("\n\nANOVA (Type I sequential):\n")
print(anova(lmm_mod))

# Extract fixed effects table
cat("\n\nFixed effects (summary table):\n")
print(summary(lmm_mod)$tTable)

# Save also a compact CSV of fixed effects
fx <- as.data.frame(summary(lmm_mod)$tTable)
fx$term <- rownames(fx)
rownames(fx) <- NULL
write.csv(fx, "/app/artifacts/fixed_effects_task1.csv", row.names = FALSE)

# Save model object for potential further parsing
saveRDS(lmm_mod, file = "/app/artifacts/model_task1.rds")

sink()
close(con)
