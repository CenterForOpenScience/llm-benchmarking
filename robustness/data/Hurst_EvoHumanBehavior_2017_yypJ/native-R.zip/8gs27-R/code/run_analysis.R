#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ppcor)
  library(jsonlite)
})

# Paths
in_path <- "/app/data/1-s2.0-S1090513816301118-mmc1.csv"
out_path <- "/app/data/execution_result.json"

# Load data
DF <- readr::read_csv(in_path, show_col_types = FALSE)

# Ensure numeric types
num_cols <- c("DSM5_Total", "MiniK_Total", "HKSS_Total", "Age")
for (col in num_cols) {
  if (!col %in% names(DF)) {
    stop(sprintf("Required column '%s' not found in dataset.", col))
  }
  DF[[col]] <- suppressWarnings(as.numeric(DF[[col]]))
}

# Helper for partial correlation with Age control
pcor_with_age <- function(y, x, age, method = "pearson") {
  dat <- data.frame(y = y, x = x, age = age)
  dat <- dat[complete.cases(dat), ]
  if (nrow(dat) < 5) {
    return(list(estimate = NA_real_, p.value = NA_real_, t.value = NA_real_, df = NA_integer_, n = nrow(dat)))
  }
  res <- try(ppcor::pcor.test(dat$y, dat$x, dat["age"], method = method), silent = TRUE)
  if (inherits(res, "try-error")) {
    return(list(estimate = NA_real_, p.value = NA_real_, t.value = NA_real_, df = NA_integer_, n = nrow(dat)))
  }
  n <- nrow(dat)
  k <- 1L  # number of controls (Age)
  df_calc <- n - k - 2L
  t_calc <- as.numeric(res$estimate) * sqrt(df_calc / (1 - as.numeric(res$estimate)^2))
  list(
    estimate = unname(res$estimate),
    p.value = unname(res$p.value),
    t.value = unname(t_calc),
    df = df_calc,
    n = n
  )
}

# Task1: Partial correlations
pc_minik <- pcor_with_age(DF$DSM5_Total, DF$MiniK_Total, DF$Age)
pc_hkss  <- pcor_with_age(DF$DSM5_Total, DF$HKSS_Total, DF$Age)

# Task2: Mann-Whitney fast vs slow groups based on MiniK_Total thresholds
sub2 <- DF %>% dplyr::select(MiniK_Total, DSM5_Total) %>% dplyr::filter(!is.na(MiniK_Total), !is.na(DSM5_Total))
sub2 <- sub2 %>% dplyr::mutate(
  Life_Strategy = dplyr::case_when(
    MiniK_Total <= -1 ~ 0L,  # fast
    MiniK_Total >= 1  ~ 1L,  # slow
    TRUE ~ NA_integer_
  )
) %>% dplyr::filter(!is.na(Life_Strategy))

n_slow <- sum(sub2$Life_Strategy == 1L)
n_fast <- sum(sub2$Life_Strategy == 0L)

mw <- list(W = NA_real_, p.value = NA_real_, n_fast = n_fast, n_slow = n_slow, r_rank_biserial = NA_real_,
           mean_fast = NA_real_, mean_slow = NA_real_, median_fast = NA_real_, median_slow = NA_real_)

if (n_fast > 0 && n_slow > 0) {
  x_slow <- sub2$DSM5_Total[sub2$Life_Strategy == 1L]
  y_fast <- sub2$DSM5_Total[sub2$Life_Strategy == 0L]
  # Compute p-value via wilcox.test
  wt <- suppressWarnings(wilcox.test(x = x_slow, y = y_fast, paired = FALSE, exact = FALSE, correct = FALSE))
  pval <- unname(wt$p.value)
  # Compute rank sums and rank-biserial correlation deterministically
  combined <- c(x_slow, y_fast)
  ranks <- rank(combined, ties.method = "average")
  R_slow <- sum(ranks[seq_along(x_slow)])
  # U for slow group
  U_slow <- R_slow - (n_slow * (n_slow + 1)) / 2
  r_rb <- (2 * U_slow) / (n_slow * n_fast) - 1
  mw$W <- as.numeric(R_slow)
  mw$p.value <- as.numeric(pval)
  mw$r_rank_biserial <- as.numeric(r_rb)
  mw$mean_fast <- mean(y_fast)
  mw$mean_slow <- mean(x_slow)
  mw$median_fast <- stats::median(y_fast)
  mw$median_slow <- stats::median(x_slow)
}

# Compose execution result
result <- list(
  task_outputs = list(
    list(
      task_id = "Task1",
      metric = "partial_correlation",
      results = list(
        MiniK_vs_DSM5_ctrl_Age = pc_minik,
        HKSS_vs_DSM5_ctrl_Age = pc_hkss
      )
    ),
    list(
      task_id = "Task2",
      metric = "mann_whitney",
      results = mw
    )
  )
)

# Write JSON output
jsonlite::write_json(result, path = out_path, auto_unbox = TRUE, pretty = TRUE)
cat(sprintf("Results written to %s\n", out_path))
