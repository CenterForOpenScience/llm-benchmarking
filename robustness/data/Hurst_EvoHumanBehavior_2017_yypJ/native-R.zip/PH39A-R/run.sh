#!/usr/bin/env bash
set -euo pipefail

# Render the R Markdown analysis notebook to HTML artifact
R -q -e 'rmarkdown::render("/app/data/analysis.Rmd", output_file="/app/artifacts/Analysis-Notebook.html")'

# Compute Spearman correlation (one-sided, alternative="less") and write a JSON summary
R -q -e '
  suppressPackageStartupMessages({library(jsonlite)})
  d <- read.csv("/app/data/data.csv")
  ct <- cor.test(d$DSM5_Total, d$MiniK_Total, method = "spearman", alternative = "less", use = "complete.obs")
  n <- sum(complete.cases(d$DSM5_Total, d$MiniK_Total))
  res <- list(metric = "spearman_rho", value = unname(ct$estimate), p_value = ct$p.value, sample_size = n,
              direction = ifelse(unname(ct$estimate) < 0, "negative", ifelse(unname(ct$estimate) > 0, "positive", "zero")))
  write_json(res, path = "/app/artifacts/results_ph39a.json", auto_unbox = TRUE)
'