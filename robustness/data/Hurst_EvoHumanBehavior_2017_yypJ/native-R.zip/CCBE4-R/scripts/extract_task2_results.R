# Task2 extraction: compute partial correlation MiniK_Total ~~ DSM5_Total controlling for Age
req <- function(pkgs){
  for(p in pkgs){
    if(!requireNamespace(p, quietly = TRUE)){
      install.packages(p, repos = "https://cloud.r-project.org")
    }
  }
}
req(c("lavaan","jsonlite"))
library(lavaan)
library(jsonlite)

# Load data
candidates <- c(
  Sys.getenv("PAPERROBUST_DATASET", unset = ""),
  "/app/data/Dataset.csv",
  "/workspace/data/Dataset.csv",
  "data/Dataset.csv",
  "Dataset.csv"
)
candidates <- candidates[nchar(candidates) > 0]
path <- candidates[file.exists(candidates)][1]
if(is.na(path)) stop("Dataset.csv not found for extraction.")
dat <- read.csv(path)

mod_minik <- "\nMiniK_Total + DSM5_Total ~ Age\n\nDSM5_Total ~~ MiniK_Total\n"
fit_minik <- sem(mod_minik, data = dat, estimator = "MLR", missing = "listwise")
pe <- parameterEstimates(fit_minik, standardized = TRUE)
row <- pe[pe$op == "~~" & ((pe$lhs == "DSM5_Total" & pe$rhs == "MiniK_Total") | (pe$lhs == "MiniK_Total" & pe$rhs == "DSM5_Total")), ]
r <- if(nrow(row) >= 1) as.numeric(row$std.all[1]) else NA_real_
pval <- if(nrow(row) >= 1) as.numeric(row$pvalue[1]) else NA_real_
N <- as.numeric(lavInspect(fit_minik, "nobs"))

entry <- list(
  Task2 = list(
    MiniK_DSM5 = list(r = r, p_value = pval, sample_size = N)
  )
)

artifact_dir <- Sys.getenv("PAPERROBUST_ARTIFACTS", unset = "/tmp/paperrobust_artifacts")
dir.create(artifact_dir, recursive = TRUE, showWarnings = FALSE)
out_path <- file.path(artifact_dir, "execution_result.json")
if(file.exists(out_path)){
  existing <- tryCatch(jsonlite::read_json(out_path, simplifyVector = FALSE), error = function(e) NULL)
  if(is.null(existing) || !is.list(existing)) existing <- list()
  existing$Task2 <- entry$Task2
  jsonlite::write_json(existing, out_path, auto_unbox = TRUE, pretty = TRUE)
} else {
  jsonlite::write_json(entry, out_path, auto_unbox = TRUE, pretty = TRUE)
}
cat("Task2 extraction complete.\n")

# Also print JSON to stdout for capture
cat("TASK2_JSON_START\n")
cat(jsonlite::toJSON(entry, auto_unbox = TRUE, pretty = FALSE))
cat("\nTASK2_JSON_END\n")

