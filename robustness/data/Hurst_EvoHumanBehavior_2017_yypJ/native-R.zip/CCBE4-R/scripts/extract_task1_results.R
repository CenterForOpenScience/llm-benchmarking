# Task1 extraction: compute partial correlations and write to artifact execution_result.json
req <- function(pkgs){
  for(p in pkgs){
    if(!requireNamespace(p, quietly = TRUE)){
      install.packages(p, repos = "https://cloud.r-project.org")
    }
  }
}
req(c("lavaan","jsonlite","psych"))
library(lavaan)
library(jsonlite)

# Load data
candidates <- c(
  Sys.getenv("PAPERROBUST_DATASET", unset = ""),
  "/app/data/Dataset.csv",
  "/workspace/data/Dataset.csv",
  "data/Dataset.csv",
  "Dataset.csv"
)
candidates <- candidates[nchar(candidates) > 0]
path <- candidates[file.exists(candidates)][1]
if(is.na(path)) stop("Dataset.csv not found for extraction.")
dat <- read.csv(path)

# Helper to extract partial correlation and p-value from a lavaan fit for lhs~~rhs
extract_cor <- function(fit, v1, v2){
  pe <- parameterEstimates(fit, standardized = TRUE)
  row <- pe[pe$op == "~~" & ((pe$lhs == v1 & pe$rhs == v2) | (pe$lhs == v2 & pe$rhs == v1)), ]
  if(nrow(row) < 1) return(list(r = NA_real_, p = NA_real_))
  list(r = as.numeric(row$std.all[1]), p = as.numeric(row$pvalue[1]))
}

# Single-variable models
mod_minik <- "\nMiniK_Total + DSM5_Total ~ Age\n\nDSM5_Total ~~ MiniK_Total\n"
fit_minik <- sem(mod_minik, data = dat, estimator = "MLR", missing = "listwise")
res_minik <- extract_cor(fit_minik, "DSM5_Total", "MiniK_Total")
N_minik <- as.numeric(lavInspect(fit_minik, "nobs"))

mod_hkss <- "\nHKSS_Total + DSM5_Total ~ Age\n\nDSM5_Total ~~ HKSS_Total\n"
fit_hkss <- sem(mod_hkss, data = dat, estimator = "MLR", missing = "listwise")
res_hkss <- extract_cor(fit_hkss, "DSM5_Total", "HKSS_Total")
N_hkss <- as.numeric(lavInspect(fit_hkss, "nobs"))

# Combined model
mod_comb <- "\nMiniK_Total + HKSS_Total + DSM5_Total ~ Age\n\nDSM5_Total ~~ HKSS_Total + MiniK_Total\nHKSS_Total ~~ MiniK_Total\n"
fit_comb <- sem(mod_comb, data = dat, estimator = "MLR", missing = "listwise")
res_comb_mk <- extract_cor(fit_comb, "DSM5_Total", "MiniK_Total")
res_comb_hk <- extract_cor(fit_comb, "DSM5_Total", "HKSS_Total")
N_comb <- as.numeric(lavInspect(fit_comb, "nobs"))

# PCA composite sensitivity
req(c("psych"))
if(requireNamespace("psych", quietly = TRUE)){
  pca <- try(psych::principal(dat[, c("MiniK_Total","HKSS_Total")], scores = TRUE), silent = TRUE)
  if(!inherits(pca, "try-error") && !is.null(pca$scores)){
    dat$compscores <- as.numeric(pca$scores[,1])
    mod_pca <- "\ncompscores + DSM5_Total ~ Age\n\ncompscores ~~ DSM5_Total\n"
    fit_pca <- sem(mod_pca, data = dat, estimator = "MLR", missing = "listwise")
    res_pca <- extract_cor(fit_pca, "DSM5_Total", "compscores")
    N_pca <- as.numeric(lavInspect(fit_pca, "nobs"))
  } else {
    res_pca <- list(r = NA_real_, p = NA_real_)
    N_pca <- NA_real_
  }
} else {
  res_pca <- list(r = NA_real_, p = NA_real_)
  N_pca <- NA_real_
}

# Build result structure
entry <- list(
  Task1 = list(
    single = list(
      MiniK_DSM5 = list(r = res_minik$r, p_value = res_minik$p, sample_size = N_minik),
      HKSS_DSM5  = list(r = res_hkss$r, p_value = res_hkss$p, sample_size = N_hkss)
    ),
    combined = list(
      MiniK_DSM5 = list(r = res_comb_mk$r, p_value = res_comb_mk$p, sample_size = N_comb),
      HKSS_DSM5  = list(r = res_comb_hk$r, p_value = res_comb_hk$p, sample_size = N_comb)
    ),
    pca = list(
      Composite_DSM5 = list(r = res_pca$r, p_value = res_pca$p, sample_size = N_pca)
    )
  )
)

# Determine artifact dir and write execution_result.json there
artifact_dir <- Sys.getenv("PAPERROBUST_ARTIFACTS", unset = "/tmp/paperrobust_artifacts")
dir.create(artifact_dir, recursive = TRUE, showWarnings = FALSE)
out_path <- file.path(artifact_dir, "execution_result.json")
if(file.exists(out_path)){
  existing <- tryCatch(jsonlite::read_json(out_path, simplifyVector = FALSE), error = function(e) NULL)
  if(is.null(existing) || !is.list(existing)) existing <- list()
  existing$Task1 <- entry$Task1
  jsonlite::write_json(existing, out_path, auto_unbox = TRUE, pretty = TRUE)
} else {
  jsonlite::write_json(entry, out_path, auto_unbox = TRUE, pretty = TRUE)
}
cat("Task1 extraction complete.\n")

# Also print JSON to stdout for capture
cat("TASK1_JSON_START\n")
cat(jsonlite::toJSON(entry, auto_unbox = TRUE, pretty = FALSE))
cat("\nTASK1_JSON_END\n")

