#!/usr/bin/env bash
set -euo pipefail
R -q -e "rmarkdown::render('data/Multi100_1.Rmd', output_dir='artifacts', intermediates_dir='tmp')"