library(readr)
suppressPackageStartupMessages({
  require(dplyr)
  require(tidyr)
  require(tidyverse)
  require(ggplot2)
  require(infotheo)
  require(igraph)
  require(NetworkToolbox)
  require(Hmisc)
})

# Fast execution helpers added by ChatGPT.
# The analytical logic is unchanged: the same entropy definition, individual networks,
# MST extraction, graph metrics, correlations, and t-tests are used.
# The changes only avoid repeated slow R loops and repeated matrix/data.frame conversions.

Sys.setenv(
  OMP_NUM_THREADS = "1",
  OPENBLAS_NUM_THREADS = "1",
  MKL_NUM_THREADS = "1",
  VECLIB_MAXIMUM_THREADS = "1"
)

get_paperrobust_cores <- function(){
  env_cores <- suppressWarnings(as.integer(Sys.getenv("PAPERROBUST_CORES", unset = NA_character_)))
  if(!is.na(env_cores) && env_cores > 0){
    return(max(1L, env_cores))
  }
  detected <- parallel::detectCores(logical = TRUE)
  if(is.na(detected) || detected < 1) detected <- 1
  # Conservative laptop-safe default. Increase with PAPERROBUST_CORES if needed.
  max(1L, min(2L, detected - 1L))
}

find_existing_file <- function(candidates, label){
  candidates <- candidates[nchar(candidates) > 0]
  hit <- candidates[file.exists(candidates)][1]
  if(is.na(hit)){
    stop(paste(label, "not found. Tried:", paste(candidates, collapse = " | ")))
  }
  hit
}

choose_writable_dir <- function(candidates){
  candidates <- candidates[nchar(candidates) > 0]
  for(d in candidates){
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
    test_file <- file.path(d, paste0(".write_test_", Sys.getpid()))
    ok <- tryCatch({
      writeLines("ok", test_file)
      unlink(test_file)
      TRUE
    }, error = function(e) FALSE)
    if(ok) return(d)
  }
  return(tempdir())
}

write_json_safely <- function(obj, filename){
  if(!requireNamespace("jsonlite", quietly = TRUE)) return(invisible(NULL))
  out_dir <- choose_writable_dir(c(
    Sys.getenv("PAPERROBUST_OUTPUT_DIR", unset = ""),
    "/app/data",
    "/workspace/data",
    "data",
    ".",
    tempdir()
  ))
  out_path <- file.path(out_dir, filename)
  jsonlite::write_json(obj, path = out_path, auto_unbox = TRUE, pretty = TRUE)
  message(sprintf("Wrote JSON result to: %s", out_path))
  invisible(out_path)
}

write_csv_safely <- function(x, filename){
  out_dir <- choose_writable_dir(c(
    Sys.getenv("PAPERROBUST_OUTPUT_DIR", unset = ""),
    "/app/data",
    "/workspace/data",
    "data",
    ".",
    tempdir()
  ))
  out_path <- file.path(out_dir, filename)
  write.csv(x, file = out_path, row.names = TRUE)
  message(sprintf("Wrote CSV artifact to: %s", out_path))
  invisible(out_path)
}

build_entropy_matrix_fast <- function(tt){
  tt_mat <- as.matrix(tt)
  list_of_words <- na.omit(unique(as.vector(tt_mat)))
  list_of_words <- as.character(list_of_words)

  n_resp <- nrow(tt_mat)
  n_words <- length(list_of_words)

  flat <- as.vector(tt_mat)
  word_idx <- match(as.character(flat), list_of_words)
  row_idx <- rep(seq_len(n_resp), times = ncol(tt_mat))
  keep <- !is.na(word_idx)

  presence <- matrix(0L, nrow = n_resp, ncol = n_words,
                     dimnames = list(NULL, list_of_words))
  presence[cbind(row_idx[keep], word_idx[keep])] <- 1L

  cooccur <- crossprod(presence)
  p <- cooccur / n_resp

  term1 <- ifelse(p > 0, p * log2(p), 0)
  term0 <- ifelse(p < 1, (1 - p) * log2(1 - p), 0)
  entropy_full <- -(term1 + term0)

  ent_matrix <- matrix(NA_real_, nrow = n_words, ncol = n_words,
                       dimnames = list(list_of_words, list_of_words))
  lower <- lower.tri(ent_matrix, diag = TRUE)
  ent_matrix[lower] <- entropy_full[lower]

  as.data.frame(ent_matrix, check.names = FALSE)
}

Modes <- function(x) {
  ux <- unique(x)
  tab <- tabulate(match(x, ux))
  ux[tab == max(tab)]
}


# Plan:
# 1. Count the probability that two items appear in the same list.
# 2. Compute the information/entropy value from co-occurrence.
# 3. Build networks from those values.
# 4. Apply thresholds.
# 5. Compute graph metrics.

data_path <- find_existing_file(
  c(
    Sys.getenv("PAPERROBUST_DEMO_PATH", unset = ""),
    "/app/data/FINAL demo open fluency.csv",
    "/workspace/data/FINAL demo open fluency.csv",
    "data/FINAL demo open fluency.csv",
    "Data/Cleaned FINAL/FINAL demo open fluency.csv",
    "FINAL demo open fluency.csv"
  ),
  "FINAL demo open fluency.csv"
)

dem <- read_csv(data_path, show_col_types = FALSE) # Read clean data

tt <- dem %>% select(starts_with("vf_an_")) # Select semantic data
list_of_words <- na.omit(unique(unlist(tt))) # Only unique words
list_of_words <- as.character(list_of_words)

###
# Create an entropy matrix.
# Original logic:
# For each pair of words, count whether both words occur in each participant's row.
# Then compute entropy of that binary co-occurrence variable.
# Fast implementation:
# Build a participant-by-word presence matrix and use crossprod() to get all
# pair counts at once. This is algebraically the same as the original triple loop.

message("Building entropy matrix with vectorized co-occurrence counting...")
ent_matrix <- build_entropy_matrix_fast(tt)

########
# Slight modifications
ent_matrix_mod <- ent_matrix
ent_matrix_mod[is.na(ent_matrix_mod)] <- 99
ent_matrix_mod[ent_matrix_mod == 0] <- 0.99 # Entropy 1 means random process (P = 0.5), so all values without a pair get 0.99

# Save for Script 2 if the output location is writable. This does not change the analysis.
try(write_csv_safely(ent_matrix_mod, "ent_matrix_mod.csv"), silent = TRUE)

##
# Analysis by group
# openness - o_ffi # It is not clear from the data and description how exactly authors created high and low groups

# Main idea: create a network for each individual based on the total sample.

dem2 <- dem

ent_matrix_mod_mat <- as.matrix(ent_matrix_mod)
storage.mode(ent_matrix_mod_mat) <- "numeric"
word_index <- setNames(seq_along(list_of_words), list_of_words)
all_word_idx <- seq_along(list_of_words)

tt_mat <- as.matrix(tt)
row_present_idx <- lapply(seq_len(nrow(tt_mat)), function(i){
  nn <- unique(as.character(tt_mat[i, ]))
  idx <- match(nn, list_of_words)
  idx <- idx[!is.na(idx)]
  unique(idx)
})

compute_individual_metrics_task1 <- function(n){
  adj_matrix <- ent_matrix_mod_mat

  present_idx <- row_present_idx[[n]]
  lacking_idx <- setdiff(all_word_idx, present_idx) # Each individual network consists only from existing pairs of words

  if(length(lacking_idx) > 0){
    adj_matrix[lacking_idx, lacking_idx] <- 0.99
  }

  graph <- graph_from_adjacency_matrix(adj_matrix, diag = FALSE, mode = "lower", weighted = TRUE)
  graph <- mst(graph) # Extract the main structure with MST.

  cpl <- median(distances(graph, algorithm = "Dijkstra"))

  # Preserve the original call form.
  betw <- betweenness(adj_matrix, weighted = TRUE)

  part <- participation(adj_matrix, comm = "louvain")
  part_mean <- mean(part$overall[part$overall > Modes(part$overall)])

  c(
    cpl = cpl,
    betw_mean = mean(betw),
    betw_max = max(betw),
    part_mean = part_mean
  )
}

cores <- get_paperrobust_cores()
message(sprintf("Computing individual networks for Task 1 with %d core(s)...", cores))

if(.Platform$OS.type == "unix" && cores > 1L){
  metric_list <- parallel::mclapply(
    seq_len(nrow(tt_mat)),
    compute_individual_metrics_task1,
    mc.cores = cores,
    mc.preschedule = TRUE
  )
} else {
  metric_list <- vector("list", nrow(tt_mat))
  for(n in seq_len(nrow(tt_mat))){
    if(n %% 25 == 0) message(sprintf("Processed %d / %d rows", n, nrow(tt_mat)))
    metric_list[[n]] <- compute_individual_metrics_task1(n)
  }
}

metrics <- as.data.frame(do.call(rbind, metric_list))
dem2$cpl <- metrics$cpl # The decrease in CPL reflects more deterministic choice of words; increase means more random
dem2$betw_mean <- metrics$betw_mean # Higher betweenness means more nodes have random connections
dem2$betw_max <- metrics$betw_max
dem2$part_mean <- metrics$part_mean # Higher participation coefficient means more interconnectedness

# Group comparison and correlations
analysis_df <- dem2 %>%
  select(c("d_age", "d_gender", "o_ffi", "oi_bfas",
           "o_bfas", "i_bfas", "cpl", "betw_mean", "betw_max", "part_mean")) %>%
  mutate(openness_average = rowMeans(select(., c("o_ffi", "oi_bfas", "o_bfas", "i_bfas")))) %>% # Average of openness scales
  mutate(group = ifelse(openness_average > median(openness_average), "high", "low")) %>%
  filter(cpl < 10)

aux_df <- analysis_df %>%
  pivot_longer(3:10, names_to = "names", values_to = "values")

ggplot(aux_df, aes(x = openness_average, y = values)) +
  geom_point() + facet_grid(names ~ ., scales = "free") + theme_minimal()

ggplot(aux_df, aes(x = d_gender, y = values, fill = as.factor(d_gender))) +
  geom_violin() + geom_boxplot(width = 0.2) + facet_grid(names ~ ., scales = "free") + theme_minimal()

ggplot(aux_df, aes(x = group, y = values, fill = as.factor(group))) +
  geom_violin() + geom_boxplot(width = 0.2) + facet_grid(names ~ ., scales = "free") + theme_minimal()

cor_df <- select(analysis_df, c("d_age", "cpl", "betw_mean", "betw_max", "part_mean", "openness_average"))
corrs <- Hmisc::rcorr(as.matrix(cor_df), type = "spearman") # Basic correlation

res <- analysis_df %>%
  select(c("cpl", "betw_mean", "betw_max", "part_mean")) %>%
  purrr::map_df(~ broom::tidy(t.test(. ~ analysis_df$group)), .id = "var") # T-test

# Optional structured output. Does not affect the analysis.
if(requireNamespace("broom", quietly = TRUE) && requireNamespace("jsonlite", quietly = TRUE)){
  cor_openness_part <- corrs$r["openness_average", "part_mean"]
  pval_openness_part <- corrs$P["openness_average", "part_mean"]
  part_t <- res %>% dplyr::filter(var == "part_mean") %>% dplyr::slice(1)

  results_list <- list(
    task_id = "Task1",
    correlation = list(
      metric = "Spearman_r",
      value = unname(cor_openness_part),
      p_value = unname(pval_openness_part),
      outcome = "part_mean",
      predictor = "openness_average"
    ),
    ttest = list(
      metric = "Welch_t",
      t_value = part_t$statistic[[1]],
      p_value = part_t$p.value[[1]],
      estimate1 = part_t$estimate[[1]],
      estimate2 = part_t$estimate2[[1]],
      parameter = part_t$parameter[[1]]
    )
  )
  write_json_safely(results_list, "task1_results.json")
}
