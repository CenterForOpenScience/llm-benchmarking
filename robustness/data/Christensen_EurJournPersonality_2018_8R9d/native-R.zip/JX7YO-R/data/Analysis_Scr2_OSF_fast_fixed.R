library(readr)
suppressPackageStartupMessages({
  require(dplyr)
  require(tidyr)
  require(tidyverse)
  require(stats)
  require(igraph)
  require(NetworkToolbox)
  require(ggplot2)
})

# Fast execution helpers added by ChatGPT.
# The analytical logic is unchanged: the same entropy definition, individual networks,
# MST extraction, graph metrics, correlations, and t-tests are used.
# The changes only avoid repeated slow R loops and repeated matrix/data.frame conversions.

Sys.setenv(
  OMP_NUM_THREADS = "1",
  OPENBLAS_NUM_THREADS = "1",
  MKL_NUM_THREADS = "1",
  VECLIB_MAXIMUM_THREADS = "1"
)

get_paperrobust_cores <- function(){
  env_cores <- suppressWarnings(as.integer(Sys.getenv("PAPERROBUST_CORES", unset = NA_character_)))
  if(!is.na(env_cores) && env_cores > 0){
    return(max(1L, env_cores))
  }
  detected <- parallel::detectCores(logical = TRUE)
  if(is.na(detected) || detected < 1) detected <- 1
  # Conservative laptop-safe default. Increase with PAPERROBUST_CORES if needed.
  max(1L, min(2L, detected - 1L))
}

find_existing_file <- function(candidates, label){
  candidates <- candidates[nchar(candidates) > 0]
  hit <- candidates[file.exists(candidates)][1]
  if(is.na(hit)){
    stop(paste(label, "not found. Tried:", paste(candidates, collapse = " | ")))
  }
  hit
}

choose_writable_dir <- function(candidates){
  candidates <- candidates[nchar(candidates) > 0]
  for(d in candidates){
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
    test_file <- file.path(d, paste0(".write_test_", Sys.getpid()))
    ok <- tryCatch({
      writeLines("ok", test_file)
      unlink(test_file)
      TRUE
    }, error = function(e) FALSE)
    if(ok) return(d)
  }
  return(tempdir())
}

write_json_safely <- function(obj, filename){
  if(!requireNamespace("jsonlite", quietly = TRUE)) return(invisible(NULL))
  out_dir <- choose_writable_dir(c(
    Sys.getenv("PAPERROBUST_OUTPUT_DIR", unset = ""),
    "/app/data",
    "/workspace/data",
    "data",
    ".",
    tempdir()
  ))
  out_path <- file.path(out_dir, filename)
  jsonlite::write_json(obj, path = out_path, auto_unbox = TRUE, pretty = TRUE)
  message(sprintf("Wrote JSON result to: %s", out_path))
  invisible(out_path)
}

write_csv_safely <- function(x, filename){
  out_dir <- choose_writable_dir(c(
    Sys.getenv("PAPERROBUST_OUTPUT_DIR", unset = ""),
    "/app/data",
    "/workspace/data",
    "data",
    ".",
    tempdir()
  ))
  out_path <- file.path(out_dir, filename)
  write.csv(x, file = out_path, row.names = TRUE)
  message(sprintf("Wrote CSV artifact to: %s", out_path))
  invisible(out_path)
}

build_entropy_matrix_fast <- function(tt){
  tt_mat <- as.matrix(tt)
  list_of_words <- na.omit(unique(as.vector(tt_mat)))
  list_of_words <- as.character(list_of_words)

  n_resp <- nrow(tt_mat)
  n_words <- length(list_of_words)

  flat <- as.vector(tt_mat)
  word_idx <- match(as.character(flat), list_of_words)
  row_idx <- rep(seq_len(n_resp), times = ncol(tt_mat))
  keep <- !is.na(word_idx)

  presence <- matrix(0L, nrow = n_resp, ncol = n_words,
                     dimnames = list(NULL, list_of_words))
  presence[cbind(row_idx[keep], word_idx[keep])] <- 1L

  cooccur <- crossprod(presence)
  p <- cooccur / n_resp

  term1 <- ifelse(p > 0, p * log2(p), 0)
  term0 <- ifelse(p < 1, (1 - p) * log2(1 - p), 0)
  entropy_full <- -(term1 + term0)

  ent_matrix <- matrix(NA_real_, nrow = n_words, ncol = n_words,
                       dimnames = list(list_of_words, list_of_words))
  lower <- lower.tri(ent_matrix, diag = TRUE)
  ent_matrix[lower] <- entropy_full[lower]

  as.data.frame(ent_matrix, check.names = FALSE)
}

Modes <- function(x) {
  ux <- unique(x)
  tab <- tabulate(match(x, ux))
  ux[tab == max(tab)]
}


data_path <- find_existing_file(
  c(
    Sys.getenv("PAPERROBUST_DEMO_PATH", unset = ""),
    "/app/data/FINAL demo open fluency.csv",
    "/workspace/data/FINAL demo open fluency.csv",
    "data/FINAL demo open fluency.csv",
    "Data/Cleaned FINAL/FINAL demo open fluency.csv",
    "FINAL demo open fluency.csv"
  ),
  "FINAL demo open fluency.csv"
)

dem <- read_csv(data_path, show_col_types = FALSE) # Read clean data
tt <- dem %>% select(starts_with("vf_an_")) # Select semantic data
list_of_words <- na.omit(unique(unlist(tt))) # Only unique words
list_of_words <- as.character(list_of_words)

ent_candidates <- c(
  Sys.getenv("PAPERROBUST_ENT_MATRIX", unset = ""),
  "/app/data/ent_matrix_mod.csv",
  "/workspace/data/ent_matrix_mod.csv",
  "data/ent_matrix_mod.csv",
  "ent_matrix_mod.csv"
)
ent_candidates <- ent_candidates[nchar(ent_candidates) > 0]
ent_path <- ent_candidates[file.exists(ent_candidates)][1]

if(is.na(ent_path)){
  message("ent_matrix_mod.csv not found; rebuilding entropy matrix with the same vectorized logic used in Script 1.")
  ent_matrix_mod <- build_entropy_matrix_fast(tt)
  ent_matrix_mod[is.na(ent_matrix_mod)] <- 99
  ent_matrix_mod[ent_matrix_mod == 0] <- 0.99
  try(write_csv_safely(ent_matrix_mod, "ent_matrix_mod.csv"), silent = TRUE)
} else {
  message(sprintf("Reading entropy matrix from: %s", ent_path))
  ent_df <- read.csv(ent_path, check.names = FALSE)
  rownames(ent_df) <- ent_df[[1]]
  ent_matrix_mod <- ent_df[-1]
}

ent_matrix_mod_mat <- as.matrix(ent_matrix_mod)
storage.mode(ent_matrix_mod_mat) <- "numeric"
list_of_matrix_words <- colnames(ent_matrix_mod_mat)

dem2 <- dem

tt_mat <- as.matrix(tt)
row_clean_idx <- lapply(seq_len(nrow(tt_mat)), function(i){
  nn <- unique(as.character(tt_mat[i, ]))
  nn <- nn[!is.na(nn)]
  nn <- nn[nn != "99"]
  idx <- match(nn, list_of_matrix_words)
  if(any(is.na(idx))){
    stop(sprintf("Some row words were not found in ent_matrix_mod at row %d.", i))
  }
  unique(idx)
})

compute_individual_metrics_task2 <- function(n){
  if(n %in% c(386, 499)){ # original explicit exclusion
    return(c(cpl = NA_real_, betw_mean = NA_real_, betw_max = NA_real_, part_mean = NA_real_))
  }

  idx <- row_clean_idx[[n]]
  if(length(idx) < 2){
    return(c(cpl = NA_real_, betw_mean = NA_real_, betw_max = NA_real_, part_mean = NA_real_))
  }

  adj_matrix <- ent_matrix_mod_mat[idx, idx, drop = FALSE]
  adj_matrix[adj_matrix == 99] <- 0
  adj_matrix <- adj_matrix + t(adj_matrix)
  adj_matrix[adj_matrix > 49] <- 0

  graph <- graph_from_adjacency_matrix(adj_matrix, diag = FALSE, mode = "lower", weighted = TRUE)

  weights <- eigen_centrality(graph)$vector
  sorted_weights <- sort(weights)
  nt <- length(weights)
  cutoff <- sorted_weights[ceiling(nt * 0.9)]
  nodes_to_remove <- which(weights > cutoff)
  graph <- delete_vertices(graph, nodes_to_remove)

  graph <- mst(graph)

  cpl <- median(distances(graph, algorithm = "Dijkstra"))
  betw <- betweenness(graph, weights = E(graph)$weight, directed = FALSE)

  part <- participation(as_adjacency_matrix(graph, attr = "weight", sparse = FALSE), comm = "louvain")
  part_mean <- mean(part$overall[part$overall > Modes(part$overall)])

  if(is.na(part_mean)){
    part_mean <- mean(part$overall)
  }

  c(
    cpl = cpl,
    betw_mean = mean(betw),
    betw_max = max(betw),
    part_mean = mean(part_mean)
  )
}

cores <- get_paperrobust_cores()
message(sprintf("Computing individual networks for Task 2 with %d core(s)...", cores))

if(.Platform$OS.type == "unix" && cores > 1L){
  metric_list <- parallel::mclapply(
    seq_len(nrow(tt_mat)),
    compute_individual_metrics_task2,
    mc.cores = cores,
    mc.preschedule = TRUE
  )
} else {
  metric_list <- vector("list", nrow(tt_mat))
  for(n in seq_len(nrow(tt_mat))){
    if(n %% 25 == 0) message(sprintf("Processed %d / %d rows", n, nrow(tt_mat)))
    metric_list[[n]] <- compute_individual_metrics_task2(n)
  }
}

metrics <- as.data.frame(do.call(rbind, metric_list))
dem2$cpl <- metrics$cpl
dem2$betw_mean <- metrics$betw_mean
dem2$betw_max <- metrics$betw_max
dem2$part_mean <- metrics$part_mean

analysis_df <- dem2 %>%
  select(c("d_age", "d_gender", "o_ffi", "oi_bfas",
           "o_bfas", "i_bfas", "cpl", "betw_mean", "betw_max", "part_mean")) %>%
  mutate(openness_average = rowMeans(select(., c("o_ffi", "oi_bfas", "o_bfas", "i_bfas")))) %>%
  mutate(group = ifelse(openness_average > median(openness_average), "high", "low")) %>%
  filter(cpl < 10) %>%
  filter(d_gender != "-1")

aux_df <- analysis_df %>%
  pivot_longer(3:10, names_to = "names", values_to = "values")

ggplot(aux_df, aes(x = d_gender, y = values, fill = as.factor(d_gender))) +
  geom_violin() + geom_boxplot(width = 0.2) + facet_grid(names ~ ., scales = "free") + theme_minimal()

t.test(analysis_df$part_mean ~ analysis_df$d_gender)

# Write structured Task2 output (Welch t-test by gender)
if(requireNamespace("broom", quietly = TRUE) && requireNamespace("jsonlite", quietly = TRUE)){
  tt_out <- t.test(analysis_df$part_mean ~ analysis_df$d_gender)
  res_t <- broom::tidy(tt_out)

  results_list2 <- list(
    task_id = "Task2",
    ttest = list(
      metric = "Welch_t",
      t_value = res_t$statistic[[1]],
      p_value = res_t$p.value[[1]],
      estimate1 = res_t$estimate[[1]],
      estimate2 = res_t$estimate2[[1]],
      parameter = res_t$parameter[[1]],
      group1 = levels(as.factor(analysis_df$d_gender))[1],
      group2 = levels(as.factor(analysis_df$d_gender))[2]
    )
  )

  write_json_safely(results_list2, "task2_results.json")
}
