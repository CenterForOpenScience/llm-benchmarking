#############
### ABOUT ###
#############

## Analyst: David Moreau, University of Auckland, d.moreau@auckland.ac.nz - ID = GHZ5E

## Paper Title: Remotely Close Associations: Openness to Experience and Semantic Memory Structure

## Paper ID: Christensen_EurJournPersonality_2018_8R9d

## Claim to test
##... the high openness to experience group’s network was more interconnected ... 
## than the low openness to experience group (p. 480.)

################
### ANALYSIS ###
################

# Load packages
# Keep heavy BLAS libraries from oversubscribing CPU when bootstrap is parallelized.
Sys.setenv(
  OMP_NUM_THREADS = "1",
  OPENBLAS_NUM_THREADS = "1",
  MKL_NUM_THREADS = "1",
  VECLIB_MAXIMUM_THREADS = "1"
)

suppressPackageStartupMessages({
  library(SemNeT)
  library(SemNetCleaner)
  library(NetworkToolbox)
})

get_parallel_cores <- function(requested = NULL, iter = NULL){
  env_cores <- suppressWarnings(as.integer(Sys.getenv("PAPERROBUST_CORES", unset = NA_character_)))
  if(!is.na(env_cores) && env_cores > 0){
    cores <- env_cores
  } else if(!is.null(requested) && !is.na(suppressWarnings(as.integer(requested))) && as.integer(requested) > 0){
    cores <- as.integer(requested)
  } else {
    detected <- parallel::detectCores(logical = TRUE)
    if(is.na(detected) || detected < 1) detected <- 1
    cores <- max(1L, detected - 1L)
  }
  if(!is.null(iter)) cores <- min(cores, as.integer(iter))
  max(1L, as.integer(cores))
}

# Fallback implementations if SemNeT::partboot and partboot.test are unavailable.
# This preserves the same bootstrap logic as the previous fallback, but uses the
# cores argument. Node samples are generated before parallel execution, so the
# selected node sets are reproducible under the same seed.
if(!exists("partboot", mode = "function")){
  message("partboot not found in loaded packages; using parallel fallback implementation.")
  partboot <- function(A, B, n, iter = 1000, corr = "cosine", cores = 1, weighted = TRUE){
    set.seed(123)
    A <- as.matrix(A)
    B <- as.matrix(B)
    storage.mode(A) <- "numeric"
    storage.mode(B) <- "numeric"
    stopifnot(ncol(A) == ncol(B))

    p <- ncol(A)
    n_keep <- max(1L, min(p, as.integer(round(n))))
    selections <- replicate(iter, sample.int(p, n_keep), simplify = FALSE)

    one_iter <- function(sel){
      As <- A[, sel, drop = FALSE]
      Bs <- B[, sel, drop = FALSE]

      cA <- SemNeT::similarity(As, method = corr)
      cB <- SemNeT::similarity(Bs, method = corr)
      diag(cA) <- 1
      diag(cB) <- 1

      gA <- NetworkToolbox::TMFG(cA)$A
      gB <- NetworkToolbox::TMFG(cB)$A

      mA <- SemNeT::semnetmeas(gA, meas = c("ASPL", "CC", "Q"))
      mB <- SemNeT::semnetmeas(gB, meas = c("ASPL", "CC", "Q"))

      as.numeric(mA - mB)
    }

    cores_use <- get_parallel_cores(cores, iter)
    message(sprintf("Running partboot fallback: iter=%d, nodes=%d, cores=%d", iter, n_keep, cores_use))

    if(.Platform$OS.type == "unix" && cores_use > 1L){
      vals <- parallel::mclapply(
        selections,
        one_iter,
        mc.cores = cores_use,
        mc.preschedule = TRUE,
        mc.set.seed = FALSE
      )
    } else {
      vals <- lapply(selections, one_iter)
    }

    diffs <- do.call(rbind, vals)
    colnames(diffs) <- c("ASPL", "CC", "Q")

    out <- list(diffs = diffs, n = n_keep, iter = iter, corr = corr, weighted = weighted)
    class(out) <- "partboot_fallback"
    return(out)
  }
}

if(!exists("partboot.test", mode = "function")){
  message("partboot.test not found in loaded packages; using fallback implementation.")
  partboot.test <- function(x){
    diffs <- if(is.list(x) && !is.null(x$diffs)) x$diffs else as.matrix(x)
    M <- colMeans(diffs, na.rm = TRUE)
    S <- apply(diffs, 2, sd, na.rm = TRUE)
    n <- nrow(diffs)
    se <- S / sqrt(n)
    tvals <- M / se
    pvals <- 2 * pt(-abs(tvals), df = n - 1)
    res <- data.frame(
      measure = colnames(diffs),
      t = as.numeric(tvals),
      p = as.numeric(pvals),
      mean_diff = as.numeric(M),
      se = as.numeric(se)
    )
    class(res) <- c("partboot_test_fallback", "data.frame")
    return(res)
  }
}


# Helper: build IDedResp from verbal fluency responses
build_IDedResp <- function(fluency_path){
  dat <- tryCatch({
    read.csv(fluency_path, stringsAsFactors = FALSE, check.names = FALSE)
  }, error = function(e){
    stop(paste("Could not read fluency file:", fluency_path, e$message))
  })
  # Identify id and response columns
  id_col <- NULL
  if("id" %in% names(dat)){
    id_col <- "id"
  } else if("ID" %in% names(dat)){
    id_col <- "ID"
  } else {
    # assume first column is id
    id_col <- names(dat)[1]
  }
  resp_cols <- grep("^vf_", names(dat), value = TRUE)
  if(length(resp_cols) == 0){
    resp_cols <- grep("vf_", names(dat), value = TRUE)
  }
  if(length(resp_cols) == 0){
    stop("No fluency response columns (starting with 'vf_') were found.")
  }
  # Clean and tokenize responses
  clean_token <- function(x){
    x <- tolower(trimws(x))
    x <- gsub("[^a-z0-9]+", " ", x)
    x <- trimws(x)
    x[nchar(x) == 0] <- NA
    return(x)
  }
  for(col in resp_cols){
    dat[[col]] <- clean_token(dat[[col]])
  }
  # Unique vocabulary across all responses
  all_tokens <- unique(na.omit(unlist(dat[resp_cols])))
  vocab <- sort(all_tokens)
  # Build binary incidence matrix: participants x tokens
  n <- nrow(dat)
  m <- length(vocab)
  mat <- matrix(0L, nrow = n, ncol = m)
  colnames(mat) <- vocab
  for(i in seq_len(n)){
    vals <- unique(na.omit(as.character(unlist(dat[i, resp_cols]))))
    if(length(vals) > 0){
      idx <- match(vals, vocab, nomatch = 0)
      idx <- idx[idx > 0]
      if(length(idx) > 0){
        mat[i, idx] <- 1L
      }
    }
  }
  out <- data.frame(id = dat[[id_col]], mat, check.names = FALSE)
  return(out)
}

# File paths: support Docker mounts and local execution without changing analysis inputs.
find_existing_file <- function(candidates, label){
  candidates <- candidates[nchar(candidates) > 0]
  hit <- candidates[file.exists(candidates)][1]
  if(is.na(hit)){
    stop(paste(label, "not found. Tried:", paste(candidates, collapse = " | ")))
  }
  hit
}

open_path <- find_existing_file(
  c(
    Sys.getenv("PAPERROBUST_OPEN_PATH", unset = ""),
    "/app/data/FINAL open.csv",
    "/workspace/data/FINAL open.csv",
    "data/FINAL open.csv",
    "FINAL open.csv"
  ),
  "Openness file"
)

fluency_path <- find_existing_file(
  c(
    Sys.getenv("PAPERROBUST_FLUENCY_PATH", unset = ""),
    "/app/data/FINAL fluency.csv",
    "/workspace/data/FINAL fluency.csv",
    "data/FINAL fluency.csv",
    "FINAL fluency.csv"
  ),
  "Fluency file"
)


# Read latent openness data
latent <- tryCatch({
  read.csv(open_path, stringsAsFactors = FALSE, check.names = FALSE)
}, error = function(e){
  stop(paste("Could not read openness file:", open_path, e$message))
})

# Ensure expected columns exist
if(!("no_int" %in% names(latent))){
  stop("Column 'no_int' not found in openness data.")
}
if(!("id" %in% names(latent)) && !("ID" %in% names(latent))){
  stop("No 'id' column found in openness data.")
}
if(!("id" %in% names(latent)) && ("ID" %in% names(latent))){
  names(latent)[names(latent)=="ID"] <- "id"
}

# Build IDedResp from fluency responses
IDedResp <- build_IDedResp(fluency_path)

# Merge latent openness with responses by id
comb <- merge(latent[, c("id","no_int")], IDedResp, by = "id", all.x = TRUE, sort = FALSE)

# Create groups by openness (split 50/50)
ord <- order(comb$no_int)
comb_ord <- comb[ord, ]
low <- comb_ord[1:258, ]
high <- comb_ord[259:516, ]

# Remove latent variable (no_int) and ids
# Note: columns: id, no_int, then responses
deLow <- low[, -(1:2)]
deHigh <- high[, -(1:2)]

# Simple finalize: remove responses given by one or no participants; then equate nodes across groups
matLow <- as.matrix(sapply(deLow, as.numeric))
matHigh <- as.matrix(sapply(deHigh, as.numeric))
keepLow <- colSums(matLow, na.rm = TRUE) > 1
keepHigh <- colSums(matHigh, na.rm = TRUE) > 1
finLow <- matLow[, keepLow, drop = FALSE]
finHigh <- matHigh[, keepHigh, drop = FALSE]

# Equate nodes across groups via common columns
common_nodes <- intersect(colnames(finLow), colnames(finHigh))
if(length(common_nodes) < 5){
  stop("Too few common response nodes after finalize; cannot proceed.")
}
low_eq <- finLow[, common_nodes, drop = FALSE]
high_eq <- finHigh[, common_nodes, drop = FALSE]
# Create cosine similarity matrices from equated response matrices
cosLow <- similarity(low_eq, method = "cosine")
cosHigh <- similarity(high_eq, method = "cosine")
diag(cosLow) <- 1
diag(cosHigh) <- 1

# Create networks
netLow <- TMFG(cosLow)$A
netHigh <- TMFG(cosHigh)$A

# Semantic network measures
low.meas <- semnetmeas(netLow, meas = c("ASPL", "CC", "Q"))
high.meas <- semnetmeas(netHigh, meas = c("ASPL", "CC", "Q"))

# Partial network bootstrapped approach
nodedrop <- list()
iter <- 1000
parallel_cores <- get_parallel_cores(iter = iter)
message(sprintf("Using %d core(s) for bootstrap calls.", parallel_cores))

nodedrop$fifty <- partboot(high_eq, low_eq, n = ncol(high_eq) * .50, iter = iter, corr = "cosine", cores = parallel_cores, weighted = TRUE)
nodedrop$sixty <- partboot(high_eq, low_eq, n = ncol(high_eq) * .60, iter = iter, corr = "cosine", cores = parallel_cores)
nodedrop$seventy <- partboot(high_eq, low_eq, n = ncol(high_eq) * .70, iter = iter, corr = "cosine", cores = parallel_cores)
nodedrop$eighty <- partboot(high_eq, low_eq, n = ncol(high_eq) * .80, iter = iter, corr = "cosine", cores = parallel_cores)
nodedrop$ninety <- partboot(high_eq, low_eq, n = ncol(high_eq) * .90, iter = iter, corr = "cosine", cores = parallel_cores)


# Partial network bootstrapped tests
res90 <- partboot.test(nodedrop$ninety)
res80 <- partboot.test(nodedrop$eighty)
res70 <- partboot.test(nodedrop$seventy)
res60 <- partboot.test(nodedrop$sixty)
res50 <- partboot.test(nodedrop$fifty)

extract_stat <- function(x){
  out <- list(summary = capture.output(print(x)))
  return(out)
}

choose_artifacts_dir <- function(){
  candidates <- c(
    Sys.getenv("PAPERROBUST_ARTIFACTS", unset = ""),
    "/app/artifacts",
    "/workspace/artifacts",
    "artifacts",
    "/tmp/paperrobust_artifacts"
  )
  candidates <- candidates[nchar(candidates) > 0]

  for(d in candidates){
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
    test_file <- file.path(d, paste0(".write_test_", Sys.getpid()))
    ok <- tryCatch({
      writeLines("ok", test_file)
      unlink(test_file)
      TRUE
    }, error = function(e) FALSE)
    if(ok) return(d)
  }
  stop("No writable artifact directory found.")
}

artifacts_dir <- choose_artifacts_dir()
message(sprintf("Writing artifacts to: %s", artifacts_dir))


results <- list(
  task = "GHZ5E",
  measures = list(
    high = as.list(high.meas),
    low = as.list(low.meas)
  ),
  partboot = list(
    fifty = extract_stat(res50),
    sixty = extract_stat(res60),
    seventy = extract_stat(res70),
    eighty = extract_stat(res80),
    ninety = extract_stat(res90)
  )
)

jsonlite::write_json(results, file.path(artifacts_dir, "results_GHZ5E.json"), auto_unbox = TRUE, pretty = TRUE)
saveRDS(list(nodedrop = nodedrop, tests = list(res50=res50,res60=res60,res70=res70,res80=res80,res90=res90)),
        file.path(artifacts_dir, "partboot_objects_GHZ5E.rds"))

print("High openness measures (ASPL, CC, Q):")
print(high.meas)
print("Low openness measures (ASPL, CC, Q):")
print(low.meas)
print("Partial bootstrap tests (90% node retention):")
print(res90)
