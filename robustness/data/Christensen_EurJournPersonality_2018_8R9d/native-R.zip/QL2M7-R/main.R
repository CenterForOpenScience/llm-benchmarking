# Main R script to execute Task1 and Task2 analyses for Christensen_EurJournPersonality_2018_8R9d (QL2M7)
# This script reads the original dataset from /app/data, performs the planned SemNeT analyses, and
# writes structured results into /app/artifacts/execution_result.json

suppressPackageStartupMessages({
  library(dplyr)
  library(psych)
  library(PerformanceAnalytics)
  library(visdat)
  library(SemNetDictionaries)
  library(SemNetCleaner)
  library(SemNeT)
  library(jsonlite)
})

artifacts_dir <- "/workspace/artifacts"
try(dir.create(artifacts_dir, recursive = TRUE), silent = TRUE)

log_message <- function(msg){
  cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "] ", msg, "\n"))
}

# Utility: robust text cleaning using SemNetCleaner; fallback to simple cleaning if needed
make_binary_from_vf <- function(vf_df){
  # Ensure character, treat 99 as NA
  vf_chr <- as.data.frame(lapply(vf_df, function(x){
    y <- as.character(x)
    y[trimws(y) == "99"] <- NA
    y[trimws(y) == ""] <- NA
    # standardize
    y <- trimws(tolower(y))
    return(y)
  }), stringsAsFactors = FALSE)

  # Try SemNetCleaner::textcleaner with animals dictionary
  bin <- NULL
  cleaned_obj <- try({
    SemNetCleaner::textcleaner(data = vf_chr, miss = NA, partBY = "row", dictionary = "animals")
  }, silent = TRUE)

  if (!inherits(cleaned_obj, "try-error")){
    # textcleaner often returns a list with element $binary
    if (is.list(cleaned_obj) && !is.null(cleaned_obj$binary)){
      bin <- cleaned_obj$binary
    } else if (is.data.frame(cleaned_obj)){
      # Some versions may directly return a binary frame
      bin <- cleaned_obj
    }
  }

  if (is.null(bin)){
    # Fallback: simple token cleanup and wide binary incidence matrix
    log_message("SemNetCleaner::textcleaner failed; using fallback cleaner (bounded repair)")
    # Build vocabulary
    vals <- unique(na.omit(unlist(vf_chr)))
    vals <- vals[vals != "" & !is.na(vals)]
    # Construct binary incidence: row i has 1 if any cell in row equals that token
    bin <- matrix(0, nrow = nrow(vf_chr), ncol = length(vals))
    colnames(bin) <- vals
    for (i in seq_len(nrow(vf_chr))){
      row_vals <- na.omit(unique(as.character(vf_chr[i, ])))
      if (length(row_vals) > 0){
        idx <- match(row_vals, vals)
        idx <- idx[!is.na(idx)]
        if (length(idx) > 0) bin[i, idx] <- 1
      }
    }
    bin <- as.data.frame(bin)
  }

  # Ensure binary numeric 0/1
  bin[] <- lapply(bin, function(x){ as.numeric(x > 0) })
  return(as.data.frame(bin))
}

# Load data
input_path <- "/app/data/FINAL demo open fluency.csv"
log_message(paste("Reading data from", input_path))
# Use read.csv (comma delimiter)
dat <- tryCatch({
  read.csv(input_path, stringsAsFactors = FALSE, na.strings = c("", "NA"))
}, error = function(e){
  # Try read.csv2 if delimiter issue
  read.csv2(input_path, stringsAsFactors = FALSE, na.strings = c("", "NA"))
})

# Keep only needed columns by name
vf_cols <- grep("^vf_an_\\d+", names(dat), value = TRUE)
# Sort and keep first 35 responses
vf_num <- as.integer(sub("^vf_an_(\\d+)$", "\\1", vf_cols))
vf_cols <- vf_cols[order(vf_num)]
if (length(vf_cols) >= 35) vf_cols <- vf_cols[1:35]

needed <- c("id","Sample","o_ffi","oi_bfas","o_neo", vf_cols)
needed <- intersect(needed, names(dat))

if (!all(c("id","Sample","o_ffi","oi_bfas") %in% needed)){
  stop("Required columns are missing: id, Sample, o_ffi, oi_bfas")
}

# Subset
D <- dat[, needed]
# Coerce numeric types
D$Sample <- suppressWarnings(as.numeric(D$Sample))
D$o_ffi <- suppressWarnings(as.numeric(D$o_ffi))
D$oi_bfas <- suppressWarnings(as.numeric(D$oi_bfas))
if ("o_neo" %in% names(D)) D$o_neo <- suppressWarnings(as.numeric(D$o_neo))

# Split samples
sample_1 <- D %>% filter(Sample == 1) %>% select(id, o_ffi, oi_bfas)
sample_2 <- D %>% filter(Sample == 2) %>% select(id, o_ffi, oi_bfas, o_neo)
sample_3 <- D %>% filter(Sample == 3) %>% select(id, o_ffi, oi_bfas)

sample_1_3 <- bind_rows(sample_1, sample_3)

# Factor analysis to extract openness scores
log_message("Running factor analysis for openness factor scores")
fa_scores <- list()
if (nrow(sample_1_3) > 2){
  tmp <- sample_1_3 %>% filter(complete.cases(o_ffi, oi_bfas))
  if (nrow(tmp) >= 5){
    fa_13 <- psych::fa(tmp[, c("o_ffi","oi_bfas")], nfactors = 1, fm = "pa", correct = FALSE)
    sc_13 <- psych::factor.scores(tmp[, c("o_ffi","oi_bfas")], fa_13, method = "Bartlett")
    fa_scores[["13"]] <- data.frame(id = tmp$id, openness = as.numeric(sc_13$scores[,1]))
  }
}
if (nrow(sample_2) > 2 && "o_neo" %in% names(sample_2)){
  tmp <- sample_2 %>% filter(complete.cases(o_ffi, oi_bfas, o_neo))
  if (nrow(tmp) >= 5){
    fa_2 <- psych::fa(tmp[, c("o_ffi","oi_bfas","o_neo")], nfactors = 1, fm = "pa", correct = FALSE)
    sc_2 <- psych::factor.scores(tmp[, c("o_ffi","oi_bfas","o_neo")], fa_2, method = "Bartlett")
    fa_scores[["2"]] <- data.frame(id = tmp$id, openness = as.numeric(sc_2$scores[,1]))
  }
}

openness_FA <- bind_rows(fa_scores)
if (nrow(openness_FA) == 0){
  stop("Failed to compute openness factor scores due to insufficient data.")
}

# Merge openness score to D by id
D <- D %>% left_join(openness_FA, by = "id")

# Define groups by median split
median_openness <- median(D$openness, na.rm = TRUE)
D$group <- ifelse(!is.na(D$openness) & D$openness < median_openness, 1, ifelse(!is.na(D$openness), 2, NA))

# Extract VF responses
VF_responses <- D[, vf_cols, drop = FALSE]

# Build binary matrix from VF responses using cleaner
log_message("Cleaning VF responses and creating binary incidence matrix")
cleaned_VF <- make_binary_from_vf(VF_responses)

# Align rows with D (assumes textcleaner preserved order)
if (nrow(cleaned_VF) != nrow(D)){
  stop("Row count mismatch after cleaning VF responses.")
}

# Merge grouping variable and cleaned VF
verbal_fluency <- cbind(group = D$group, cleaned_VF)
# Keep complete cases on group
verbal_fluency <- verbal_fluency[!is.na(verbal_fluency$group), , drop = FALSE]

# Split groups
openness_low <- dplyr::filter(verbal_fluency, group == 1)
openness_high <- dplyr::filter(verbal_fluency, group == 2)
# Remove group column
openness_low <- openness_low[, -1, drop = FALSE]
openness_high <- openness_high[, -1, drop = FALSE]

# Finalize (at least two participants per response)
log_message("Finalizing matrices (minCase = 2)")
low_fin <- SemNeT::finalize(openness_low, minCase = 2)
high_fin <- SemNeT::finalize(openness_high, minCase = 2)

# Equate responses across the two networks
log_message("Equating responses across groups")
eq <- SemNeT::equate(low_fin, high_fin)
equate_low <- eq$low
equate_high <- eq$high

# Compute similarity and TMFG networks (not strictly needed for boot, but consistent with plan)
log_message("Computing similarity matrices and TMFG")
cor_low <- SemNeT::similarity(equate_low, method = "cor")
cor_high <- SemNeT::similarity(equate_high, method = "cor")
net_low <- SemNeT::TMFG(cor_low)
net_high <- SemNeT::TMFG(cor_high)

# Task 1: Case-wise bootstrap for ASPL, CC, Q
log_message("Running Task1: case-wise bootstrap (iter = 1000)")
res_task1 <- list(status = "failure", error = NULL, results = NULL)
try({
  boot1 <- SemNeT::bootSemNeT(openness_low, openness_high, method = "TMFG", type = "case", iter = 1000, sim = "cosine", cores = 1)
  tests1 <- SemNeT::test.bootSemNeT(boot1)
  # Expect tests1 to have element $Case
  if (is.list(tests1) && !is.null(tests1$Case)){
    tab <- tests1$Case
  } else {
    tab <- as.data.frame(tests1)
  }
  # Ensure rownames include ASPL, CC, Q
  rn <- rownames(tab)
  extract_row <- function(meas){
    idx <- which(toupper(rn) == toupper(meas))
    if (length(idx) == 0) return(NULL)
    row <- tab[idx[1], , drop = FALSE]
    # Standardize column names
    cn <- tolower(gsub("\\.", "_", colnames(row)))
    colnames(row) <- cn
    # Helper
    `%||%` <- function(a,b){ if (!is.null(a)) a else b }
    # Try to map common fields
    out <- list(
      df = unname(as.numeric(row[["df"]] %||% NA)),
      t_value = suppressWarnings(as.numeric(row[["t-statistic"]] %||% row[["t.statstic"]] %||% NA)),
      p_value = as.character(row[["p-value"]] %||% row[["p.value"]] %||% NA),
      lower_ci = suppressWarnings(as.numeric(row[["lower.ci"]] %||% NA)),
      upper_ci = suppressWarnings(as.numeric(row[["upper.ci"]] %||% NA)),
      d = suppressWarnings(as.numeric(row[["d"]] %||% NA)),
      mean1 = suppressWarnings(as.numeric(row[["mean1"]] %||% NA)),
      sd1 = suppressWarnings(as.numeric(row[["sd1"]] %||% NA)),
      mean2 = suppressWarnings(as.numeric(row[["mean2"]] %||% NA)),
      sd2 = suppressWarnings(as.numeric(row[["sd2"]] %||% NA)),
      direction = as.character(row[["direction"]] %||% NA)
    )
    return(out)
  }
  res_task1$results <- list(
    ASPL = extract_row("ASPL"),
    CC = extract_row("CC"),
    Q = extract_row("Q")
  )
  res_task1$status <- "success"
}, silent = TRUE)

# Task 2: Node-wise partial bootstrap for ASPL with 90% nodes retained
log_message("Running Task2: node-wise partial bootstrap (prop = 0.90, iter = 1000)")
res_task2 <- list(status = "failure", error = NULL, results = NULL)
try({
  boot2 <- SemNeT::bootSemNeT(equate_low, equate_high, method = "TMFG", type = "node", prop = 0.90, iter = 1000, sim = "cosine", cores = 1)
  tests2 <- SemNeT::test.bootSemNeT(boot2)
  tab2 <- if (is.list(tests2) && !is.null(tests2$Node)) tests2$Node else as.data.frame(tests2)
  rn2 <- rownames(tab2)
  idx2 <- which(toupper(rn2) == "ASPL")
  if (length(idx2) > 0){
    row <- tab2[idx2[1], , drop = FALSE]
    cn <- tolower(gsub("\\.",  "_", colnames(row)))
    colnames(row) <- cn
    `%||%` <- function(a,b){ if (!is.null(a)) a else b }
    res_task2$results <- list(
      ASPL = list(
        df = suppressWarnings(as.numeric(row[["df"]] %||% NA)),
        t_value = suppressWarnings(as.numeric(row[["t-statistic"]] %||% row[["t.statstic"]] %||% NA)),
        p_value = as.character(row[["p-value"]] %||% row[["p.value"]] %||% NA),
        lower_ci = suppressWarnings(as.numeric(row[["lower.ci"]] %||% NA)),
        upper_ci = suppressWarnings(as.numeric(row[["upper.ci"]] %||% NA)),
        d = suppressWarnings(as.numeric(row[["d"]] %||% NA)),
        mean1 = suppressWarnings(as.numeric(row[["mean1"]] %||% NA)),
        sd1 = suppressWarnings(as.numeric(row[["sd1"]] %||% NA)),
        mean2 = suppressWarnings(as.numeric(row[["mean2"]] %||% NA)),
        sd2 = suppressWarnings(as.numeric(row[["sd2"]] %||% NA)),
        direction = as.character(row[["direction"]] %||% NA)
      )
    )
  }
  res_task2$status <- "success"
}, silent = TRUE)

# Compose execution_result.json
overall_status <- if (res_task1$status == "success" & res_task2$status == "success") "success" else if (res_task1$status == "success" | res_task2$status == "success") "partial_success" else "failure"
out <- list(
  overall_status = overall_status,
  task1 = res_task1,
  task2 = res_task2,
  notes = list(
    n_rows = nrow(D),
    n_low = nrow(openness_low),
    n_high = nrow(openness_high)
  )
)

# Determine writable path
out_dir <- artifacts_dir
if (!dir.exists(out_dir)){
  out_dir <- "."
}

jsonlite::write_json(out, file.path(out_dir, "execution_result.json"), auto_unbox = TRUE, pretty = TRUE)
log_message(paste("Wrote results to", file.path(out_dir, "execution_result.json")))

# Also write simple per-task files
jsonlite::write_json(res_task1, file.path(out_dir, "task1_results.json"), auto_unbox = TRUE, pretty = TRUE)
jsonlite::write_json(res_task2, file.path(out_dir, "task2_results.json"), auto_unbox = TRUE, pretty = TRUE)

log_message("Done.")
